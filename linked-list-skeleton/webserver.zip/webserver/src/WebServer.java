import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.sql.SQLOutput;

public class WebServer {
    private ServerSocket serverSocket;
    private Socket clientSocket;
    private final String www = "www";
    public static void main(String[] args) throws IOException {

        WebServer webServer = new WebServer();
        webServer.validateHeader(webServer.getHeader());

        //implement a while(true){ clientSocket = serverSocket.accept(); }

    }

    public WebServer() throws IOException {
        this.serverSocket = new ServerSocket(8050);
    }


    public String getHeader() throws IOException {


        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

        String header = "";
        System.out.println("HEY!");

        header = bufferedReader.readLine();
        System.out.println(header);

        return header;
    }

    public File validateHeader(String header) throws IOException {


        DataOutputStream  dataOutputStream  = new DataOutputStream(clientSocket.getOutputStream());


        String[] wordsArray = header.split("/");
        String[] nameAndExtension = wordsArray[1].split("\\.|\\s");

        System.out.println(wordsArray[0] + " ----- " + wordsArray[1]);
        System.out.println(nameAndExtension[0] + " ----- " + nameAndExtension[1]);
        String fileName = nameAndExtension[0];
        String fileExtension = nameAndExtension[1];

        File file = new File(www + "/" + fileName + "." + fileExtension);


        String responseHeader = "HTTP/1.0 200 Document Follows\r\n" +
        "Content-Type: text/html; charset=UTF-8\r\n" +
        "Content-Length: " + file.length() + "\r\n\r\n";

        dataOutputStream.writeBytes(responseHeader);

        FileInputStream fileInputStream = new FileInputStream(file);

        byte[] buffer = new byte[1024];
        int byteSize;

        while((byteSize = fileInputStream.read(buffer)) != -1){
            dataOutputStream.write(buffer,0,byteSize);
        }



        if(fileExtension.equals("png") && fileName.equals("logo")){
            return new File("www/logo.png");
        }
        else if(fileExtension.equals("html") && fileName.equals("index")){
            return new File("www/index.html");

        }else if(fileExtension.equals("ico") && fileName.equals("favicon")){
            return new File("www/favicon.ico");
        }
            return new File("www/404.html");
        }

        public void sendData(File file){
        if(file.getName().equals("404")){
            //PrintWriter printWriter = new PrintWriter();
        }






        }

}
